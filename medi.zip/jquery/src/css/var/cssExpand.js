define( function() {
	"use strict";

	return [ "Top", "Right", "Bottom", "Left" ];
} );
